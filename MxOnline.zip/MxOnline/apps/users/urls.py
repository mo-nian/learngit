#. _*_ encoding=utf-8 -*_
#. __author__="monian"
#. Date:2018/8/12

from django.conf.urls import url,include

from .views import userInfoView,imageUploadView,pwdModifyView,sendEmailCodeView
from .views import updateEmailView,userCourseView,myFavOrgView,myFavTeacherView
from .views import myFavCourseView,myMessageView
urlpatterns = [
    url(r'info/$',userInfoView.as_view(),name='user_info'),
    url(r'image/upload/$',imageUploadView.as_view(),name='image_upload'),
    url(r'update/pwd/$',pwdModifyView.as_view(),name='update_pwd'),
    #发送邮箱验证码
    url(r'sendemail_code/$',sendEmailCodeView.as_view(),name='sendmail_code'),
    # 修改邮箱
    url(r'update_email/$', updateEmailView.as_view(), name='update_email'),

    #用户课程
    url(r'courses/$',userCourseView.as_view(),name='user_course'),
    #我的收藏
    url(r'myfav/org/$',myFavOrgView.as_view(),name='myfav_org'),
    url(r'myfav/teacher/$', myFavTeacherView.as_view(), name='myfav_teacher'),
    url(r'myfav/course/$',myFavCourseView.as_view(),name='myfav_course'),
    #我的消息
    url(r'mymessage',myMessageView.as_view(),name='mymessage')


]
