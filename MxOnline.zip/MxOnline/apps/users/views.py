# _*_ encoding:utf-8 _*_
import json

from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import render
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.backends import ModelBackend
from django.db.models import Q
from django.views.generic.base import View
from django.contrib.auth.hashers import make_password

from pure_pagination import Paginator, EmptyPage, PageNotAnInteger

from .models import UserProfile,EmailVerifyRecord,Banner
from .forms import LoginForm,RegisterForm,SearchForm,ResetForm,UploadImageForm
from .forms import UserInfoForm
from operation.models import UserCourse,UserFavorite,UserMessage
from courses.models import Course
from organization.models import CourseOrg,Teacher
from utils.email_send import send_register_email
from utils.mixin_utils import LoginRequiredMixin

# Create your views here.
class CustomBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            user = UserProfile.objects.get(Q(username = username)|Q(email=username))
            if user.check_password (password):
                return user
        except Exception as e:
            return None


class Active_User(View):
    def get(self,request,code):
        records = EmailVerifyRecord.objects.filter(code = code)
        if records:
            for record in records:
                email = record.email
                user = UserProfile.objects.get(email=email)
                user.is_active = True
                user.save()
                email_verify = EmailVerifyRecord.objects.get(code = code,send_type="register")
                email_verify.code = email_verify.code+"?"
                email_verify.save()
        else:
            return HttpResponse("链接已失效")
        return render(request,'login.html')

class RegisterView(View):
    def get(self,request):
        register_form = RegisterForm()
        return render(request,'register.html',{'register_form':register_form})
    def post(self,request):
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():
            username = request.POST.get('email','')
            if UserProfile.objects.filter(email=username):
                return render(request, 'register.html', {'register_form':register_form,'msg': "用户已存在！"})
            password = request.POST.get('password','')
            user_profile = UserProfile()
            user_profile.username = username
            user_profile.email = username
            user_profile.password = make_password(password)
            user_profile.is_active = False
            user_profile.save()

            user_message = UserMessage()
            user_message.user = user_profile.id
            user_message.message = '欢迎注册慕学在线网'
            user_message.save()

            send_register_email(username,"register")
            return render(request,'login.html')
        else:
            return render(request,'register.html',{'register_form':register_form})


class LogoutView(View):
    '''
    用户登出
    '''
    def get(self,request):
        logout(request)
        return HttpResponseRedirect(reverse("index"))



class LoginView(View):
    '''
    用户登入
    '''
    def get(self,request):
        return render(request, 'login.html', {})
    def post(self,request):
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            username = request.POST.get('username', '')
            password = request.POST.get('password', '')
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponseRedirect(reverse("index"))
                else:
                    return render(request,'login.html',{'msg':'用户未激活！'})
            else:
                return render(request, 'login.html', {'msg': '用户名或密码错误！'})
        else:
            return render(request, 'login.html', {'login_form':login_form})


class ForgetView(View):
    def get(self,request):
        search_form = SearchForm()
        return render(request,'forgetpwd.html',{'search_form':search_form})
    def post(self,request):
        search_form = SearchForm(request.POST)
        if search_form.is_valid():
            email = request.POST.get('email', '')
            send_register_email(email, "forget")
            return HttpResponse('邮件已发送，请查收！')
        else:
            return render(request,'forgetpwd.html',{'search_form':search_form})


class ResetView(View):
    def get(self,request,code):
        records = EmailVerifyRecord.objects.filter(code = code)
        if records:
            for record in records:
                email = record.email
                return render(request,'password_reset.html',{'email':email})
        else:
            return HttpResponse("链接已失效")
        return render(request,'login.html')


class ModifyView(View):
    '''
    修改密码
    '''
    def post(self,request):
        reset_form = ResetForm(request.POST)
        if reset_form.is_valid():
            pwd1 = request.POST.get('password1','')
            pwd2 = request.POST.get('password2','')
            email = request.POST.get('email','')
            if pwd1 != pwd2:
                return render(request,'password_reset.html',{'email':email,'msg':'两次密码不一致'})
            user = UserProfile.objects.get(email = email)
            user.password = make_password(pwd2)
            user.save()
            email_verify = EmailVerifyRecord.objects.get(email = email,send_type="forget")
            email_verify.code = email_verify.code+"?"
            email_verify.save()
            return render(request,'login.html')
        else:
            email = request.POST.get('email','')
            return render(request,'password_reset.html',{'email':email,'reset_form':reset_form})

#用户个人中心
class userInfoView(LoginRequiredMixin,View):
    def get(self,request):
        user = UserProfile.objects.get(id = request.user.id)
        return render(request,'usercenter-info.html',{
            'user':user,
        })

    def post(self,request):
        user_info = UserInfoForm(request.POST,instance=request.user)
        if user_info.is_valid():
            # user = request.user
            # user.nickname = user_info.cleaned_data['nick_name']
            # print(user_info.cleaned_data['nick_name'])
            # print(user.nickname)
            # user.birday = user_info.cleaned_data['birday']
            # user.gender = user_info.cleaned_data['gender']
            # user.address = user_info.cleaned_data['address']
            # user.mobile = user_info.cleaned_data['mobile']
            user_info.save()
            return HttpResponse('{"status":"success"}',content_type='application/json')
        else:
            return HttpResponse(json.dumps(user_info.errors),content_type='application/json')


class imageUploadView(LoginRequiredMixin,View):
    '''
    用户修改头像
    '''
    def post(self,request):
        '''
        image_form = UploadImageForm(request.POST,request.FILES,instance = request.user)
        if image_form.is_valid():
            image_form.save()
        :param request:
        :return:
        '''
        image_form = UploadImageForm(request.POST,request.FILES)
        if image_form.is_valid():
            image = image_form.cleaned_data['image']
            request.user.image = image
            request.user.save()
            return HttpResponse('{"status":"success"}',content_type='application/json')
        else:
            return HttpResponse('{"status":"fail"}', content_type='application/json')


class pwdModifyView(View):
    def post(self,request):
        reset_form = ResetForm(request.POST)
        if reset_form.is_valid():
            pwd1 = request.POST.get('password1','')
            pwd2 = request.POST.get('password2','')
            if pwd1 != pwd2:
                return HttpResponse('{"status":"fail","msg":"密码不一致"}',content_type='application/json')
            user = request.user
            user.password = make_password(pwd2)
            user.save()
            return HttpResponse('{"status":"success"}',content_type='application/json')
        else:
            return HttpResponse(json.dumps(reset_form.erros), content_type='application/json')


class sendEmailCodeView(LoginRequiredMixin,View):
    def get(self,request):
        email = request.GET.get('email','')
        if UserProfile.objects.filter(email = email):
            return HttpResponse('{"email":"邮箱已经存在"}', content_type='application/json')
        else:
            send_register_email(email,'update')
            return HttpResponse('{"status":"success"}',content_type='application/json')


class updateEmailView(LoginRequiredMixin,View):
    '''
    修改个人邮箱
    '''
    def post(self,request):
        email = request.POST.get('email', '')
        code = request.POST.get('code','')
        exists_record =  EmailVerifyRecord.objects.filter(email = email, code = code, send_type = 'update')
        if exists_record:
            exists_record.delete()
            user = request.user
            user.email = email
            user.save()
            return HttpResponse('{"status":"success"}', content_type='application/json')
        else:
            return HttpResponse('{"email":"验证码出错"}', content_type='application/json')


class userCourseView(LoginRequiredMixin,View):
    def get(self,request):
        courses = UserCourse.objects.filter(user = request.user)
        #得到课程的id
        courses_ids = [course.course_id for course in courses]
        my_courses = Course.objects.filter(id__in = courses_ids)
        return render(request,'usercenter-mycourse.html',{
            'my_courses':my_courses,

        })

#收藏中心
class myFavOrgView(LoginRequiredMixin,View):
    def get(self,request):
        myfav_orgs = UserFavorite.objects.filter(user = request.user, fav_type= 2)
        orgs_ids = [org.fav_id for org in myfav_orgs]
        orgs = CourseOrg.objects.filter(id__in = orgs_ids)
        return render(request,'usercenter-fav-org.html',{
            'orgs':orgs
        })


class myFavTeacherView(LoginRequiredMixin,View):
    def get(self,request):
        myfav_teachers = UserFavorite.objects.filter(user = request.user, fav_type=3)
        teachers_ids = [teacher.fav_id for teacher in myfav_teachers]
        teachers = Teacher.objects.filter(id__in = teachers_ids)
        return render(request,'usercenter-fav-teacher.html',{
            'teachers':teachers,
        })


class myFavCourseView(LoginRequiredMixin,View):
    def get(self,request):
        myfav_courses = UserFavorite.objects.filter(user = request.user, fav_type = 1)
        courses_ids = [course.fav_id for course in myfav_courses]
        courses = Course.objects.filter(id__in = courses_ids)
        return render(request,'usercenter-fav-course.html',{
            'courses':courses,

        })


#我的消息
class myMessageView(LoginRequiredMixin,View):
    def get(self,request):
        all_message = UserMessage.objects.filter(user = request.user.id)
        #未读消息置为已读
        all_unread_messages = UserMessage.objects.filter(user = request.user.id, has_read= 0)
        for unread_message in all_unread_messages:
            unread_message.has_read = 1
            unread_message.save()
        #对消息页面进行分页
        try:
            page = request.GET.get('page', 1)
        except PageNotAnInteger:
            page = 1
        # Provide Paginator with the request object for complete querystring generation
        p = Paginator(all_message, 5, request=request)
        messages = p.page(page)
        return render(request,'usercenter-message.html',{
            'messages':messages
        })

#首页配置
class indexView(View):
    def get(self,request):
        #取出轮播图
        all_banners = Banner.objects.all().order_by('index')
        courses = Course.objects.filter(is_banner=False)[:6]
        banner_courses = Course.objects.filter(is_banner=True)[:3]
        course_orgs = CourseOrg.objects.all()[:15]
        return render(request,'index.html',{
            'all_banners':all_banners,
            'courses':courses,
            'banner_courses':banner_courses,
            'course_orgs':course_orgs
        })


#全局配置 404
def page_not_found(request):
    from django.shortcuts import render_to_response
    response = render_to_response('404.html',{})
    response.status_code = 404
    return response

def page_error(request):
    from django.shortcuts import render_to_response
    response = render_to_response('500.html',{})
    response.status_code = 500
    return response
