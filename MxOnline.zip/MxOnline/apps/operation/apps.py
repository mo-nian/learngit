# _*_ encoding:utf-8 _*_
from django.apps import AppConfig


class OperationConfig(AppConfig):
    name = 'operation'
    verbose_name = u"用户操作"
