#. _*_ encoding=utf-8 -*_
#. __author__="monian"
#. Date:2018/8/10

from django.conf.urls import url,include

from .views import OrgView,AddUserAskView,homeOrgView,orgCourseView,orgDescView,orgTeacherView,AddFavView
from .views import teacherListView,teacherDetailView

urlpatterns = [
    url(r'^list/$',OrgView.as_view(),name='org_list'),
    url(r'^add_ask/$',AddUserAskView.as_view(),name='user_ask'),
    url(r'^home/(?P<org_id>\d+)/$',homeOrgView.as_view(),name='home_org'),
    url(r'^course/(?P<org_id>\d+)/$',orgCourseView.as_view(),name='org_course'),
    url(r'^desc/(?P<org_id>\d+)/$',orgDescView.as_view(),name='org_desc'),
    url(r'^org_teacher/(?P<org_id>\d+)/$',orgTeacherView.as_view(),name='org_teacher'),
    url(r'^add_fav/$',AddFavView.as_view(),name='add_fav'),


    #讲师列表url
    url(r'^teacher/list/$',teacherListView.as_view(),name='teacher_list'),
    url(r'^teacher/detail/(?P<teacher_id>\d+)/$',teacherDetailView.as_view(),name='teacher_detail')



]
