# _*_ encoding:utf-8 _*_
from django.apps import AppConfig


class OrganizationConfig(AppConfig):
    name = 'organization'
    verbose_name = u"课程机构"
