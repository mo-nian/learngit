default_app_config = "courses.apps.CoursesConfig"
