#. _*_ encoding=utf-8 -*_
#. __author__="monian"
#. Date:2018/8/8

import xadmin

from .models import Course,BannerCourse,Lesson,Video,CourseResource
from organization.models import CourseOrg

class LessonInline(object):
    model = Lesson
    extra = 0

class CourseResourceInline(object):
    model = CourseResource
    extra = 0

class CourseAdmin(object):
    list_display = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums','add_time','get_lesson_nums','go_to']
    search_fields = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums']
    list_filter = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums','add_time']
    ordering = ['-click_nums']
    readonly_fields =['students','fav_nums','click_nums']
    #后台不设置某个字段
    # exclude = ['click_nums']
    #包含外键字段
    inlines = [LessonInline,CourseResourceInline]
    #在外面即可修改字段
    list_editable = ['name','desc','detail']
    #定时刷新
    refresh_times = [3, 5]

    def queryset(self):
        qs = super(CourseAdmin,self).queryset()
        qs = qs.filter(is_banner = False)
        return qs

    def save_models(self):
        #保存课程的时候统计课程机构的课程数
        obj = self.new_obj
        obj.save()
        course_org = obj.course_org
        if course_org is not None:
            course_org.courses_num = Course.objects.filter(course_org = course_org).count()
            courses = Course.objects.filter(course_org = course_org)
            course_org.students = 0
            for course in courses:
                course_org.students += course.students
            course_org.save()



class BannerCourseAdmin(object):
    list_display = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums','add_time']
    search_fields = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums']
    list_filter = ['course_org','name','desc','detail','degree','learn_times','students','fav_nums','image','click_nums','add_time']
    ordering = ['-click_nums']
    readonly_fields =['students','fav_nums','click_nums']
    #后台不设置某个字段 exclude = ['click_nums']
    inlines = [LessonInline,CourseResourceInline]
    list_editable = ['name', 'desc', 'detail']

    def queryset(self):
        qs = super(BannerCourseAdmin,self).queryset()
        qs = qs.filter(is_banner = True)
        return qs

    def save_models(self):
        obj = self.new_obj
        obj.save()
        course_org = obj.course_org
        if course_org is not None:
            course_org.courses_num = Course.objects.filter(course_org = course_org).count()
            courses = Course.objects.filter(course_org = course_org)
            course_org.students = 0
            for course in courses:
                course_org.students += course.students
            course_org.save()

class LessonAdmin(object):
    list_display = ['course','name','add_time']
    search_fields = ['course','name']
    list_filter = ['course__name','name','add_time']

class VideoAdmin(object):
    list_display = ['lesson','name','add_time']
    search_fields = ['lesson','name']
    list_filter = ['lesson','name','add_time']

class CourseResourceAdmin(object):
    list_display = ['course','name','download','add_time']
    search_fields = ['course','name','download']
    list_filter = ['course','name','download','add_time']


xadmin.site.register(Course,CourseAdmin)
xadmin.site.register(BannerCourse,BannerCourseAdmin)
xadmin.site.register(Lesson,LessonAdmin)
xadmin.site.register(Video,VideoAdmin)
xadmin.site.register(CourseResource,CourseResourceAdmin)
