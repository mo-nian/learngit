#. _*_ encoding=utf-8 -*_
#. __author__="monian"
#. Date:2018/8/10

from django.conf.urls import url,include

from .views import courseListView,courseDetailView,AddFavView,courseInfoView,courseCommentView,addCommentView

urlpatterns = [
    url(r'^list/$',courseListView.as_view(),name='course_list'),
    url(r'^detail/(?P<course_id>\d+)/$',courseDetailView.as_view(),name='course_detail'),
    url(r'^add_fav/$',AddFavView.as_view(),name='add_fav'),
    url(r'^info/(?P<course_id>\d+)/$',courseInfoView.as_view(),name='course_info'),
    #课程评论
    url(r'^comment/(?P<course_id>\d+)/$',courseCommentView.as_view(),name='course_comment'),
    #添加评论
    url(r'^add_comment/$',addCommentView.as_view(),name='add_comments'),


]
