# _*_ encoding:utf-8 _*_
from django.shortcuts import render
from django.views.generic.base import View
from django.http import HttpResponse
from django.db.models import Q

from pure_pagination import Paginator, EmptyPage, PageNotAnInteger
from operation.models import UserFavorite,UserCourse,CourseComments
from .models import  Course,Lesson,CourseResource
from organization.models import CourseOrg,Teacher
from utils.mixin_utils import LoginRequiredMixin
# Create your views here.

class courseListView(View):
    def get(self,request):
        all_courses = Course.objects.all().order_by('-add_time')
        hot_courses = Course.objects.all().order_by('-click_nums')[:3]
        #课程搜索
        search_keywords = request.GET.get('keywords','')
        if search_keywords:
            all_courses = all_courses.filter(Q(name__icontains=search_keywords)|Q(desc__icontains=search_keywords)|Q(detail__icontains=search_keywords))
        sort = request.GET.get('sort','')
        if sort:
            if sort == 'hot':
                all_courses = all_courses.order_by('-click_nums')
            elif sort == 'student':
                all_courses = all_courses.order_by('-students')

        # 对课程进行分页
        org_nums = all_courses.count()
        try:
            page = request.GET.get('page', 1)
        except PageNotAnInteger:
            page = 1
        # Provide Paginator with the request object for complete querystring generation
        p = Paginator(all_courses, 6, request=request)
        courses = p.page(page)
        return render(request,'course-list.html',{
            'all_courses':courses,
            'sort':sort,
            'hot_courses':hot_courses,

        })


class courseDetailView(View):
    '''
    课程详情页
    '''
    def get(self,request,course_id):
        course = Course.objects.get(id = course_id)
        #增加课程点击数
        course.click_nums += 1
        course.save()
        tag = course.tag
        if tag:
            related_course = Course.objects.filter(tag = tag)[:1]
        else:
            related_course = []
        if request.user.is_authenticated:
            #判断用户是否已登录，如果登录，就判断数据库里是否有相应的信息
            course_fav = UserFavorite.objects.filter(user=request.user,fav_id = course.id,fav_type=1)
            org_fav = UserFavorite.objects.filter(user=request.user,fav_id =course.course_org.id,fav_type=2)
        else:
            course_fav = None
            org_fav = None
        return render(request,'course-detail.html',{
            'course':course,
            'related_course':related_course,
            'course_fav':course_fav,
            'org_fav':org_fav



        })


class AddFavView(View):
    def post(self,request):
        fav_id = request.POST.get('fav_id','')
        fav_type = request.POST.get('fav_type','')
        user = request.user
        #判断用户是否登录
        if not user.is_authenticated:
            return HttpResponse('{"status":"fail","msg":"用户未登录"}', content_type='application/json')

        record = UserFavorite.objects.filter(fav_type=int(fav_type),fav_id=int(fav_id))
        if record:
            record.delete()
            if int(fav_type) == 1:
                course = Course.objects.get(id = int(fav_id))
                course.fav_nums -= 1
                course.save()
            if int(fav_type) == 2:
                org = CourseOrg.objects.get(id = int(fav_id))
                org.fav_nums -= 1
                org.save()
            if int(fav_type) == 3:
                teacher = Teacher.objects.get(id = int(fav_id))
                teacher.fav_nums -= 1
                teacher.save()
            return HttpResponse('{"status":"fail","msg":"收藏"}',content_type='application/json')
        else:
            user_fav = UserFavorite()
            if int(fav_id) > 0 and int(fav_type) > 0:
                user_fav.user = user
                user_fav.fav_type = int(fav_type)
                user_fav.fav_id = int(fav_id)
                user_fav.save()
                if int(fav_type) == 1:
                    course = Course.objects.get(id=int(fav_id))
                    course.fav_nums += 1
                    course.save()
                if int(fav_type) == 2:
                    org = CourseOrg.objects.get(id=int(fav_id))
                    org.fav_nums += 1
                    org.save()
                if int(fav_type) == 3:
                    teacher = Teacher.objects.get(id=int(fav_id))
                    teacher.fav_nums += 1
                    teacher.save()
                return HttpResponse('{"status":"success","msg":"已收藏"}',content_type='application/json')
            else:
                return HttpResponse('{"status":"fail","msg":"收藏失败"}',content_type='application/json')


class courseInfoView(LoginRequiredMixin,View):
    def get(self,request,course_id):
        course = Course.objects.get(id = course_id)
        lessons = Lesson.objects.filter(course_id = course_id)
        course_resource = CourseResource.objects.filter(course_id = course_id)
        #用户点击开始学习后 把信息存储 判断用户是否关联了课程
        if not UserCourse.objects.filter(user = request.user, course = course):
            user_course = UserCourse(user = request.user,course = course)
            user_course.save()
            course.students += 1
            course.save()
        #others = course.get_learn_users()
        user_courses = UserCourse.objects.filter(course = course)
        #学过该课程的所有用户id
        user_ids = [user_course.user.id for user_course in user_courses]
        #根据用户id得到用户学的课程
        all_user_courses = UserCourse.objects.filter(user_id__in = user_ids)
        #得到所学过的课程的id
        courses_ids = [all_user_course.course_id for all_user_course in all_user_courses]
        #根据课程id获得所有的课程 并根据点击量排序
        relate_courses = Course.objects.filter(id__in = courses_ids).order_by('-click_nums')[:5]
        return render(request,'course-video.html',{
            'course':course,
            'lessons':lessons,
            'course_resource':course_resource,
            'relate_courses':relate_courses
        })


class courseCommentView(LoginRequiredMixin,View):
    def get(self,request,course_id):
        course = Course.objects.get(id = course_id)
        course_resource = CourseResource.objects.filter(course_id=course_id)
        all_comments = CourseComments.objects.filter(course = course).order_by('-add_time')
        user_courses = UserCourse.objects.filter(course = course)
        #学过该课程的所有用户id
        user_ids = [user_course.user.id for user_course in user_courses]
        #根据用户id得到用户学的课程
        all_user_courses = UserCourse.objects.filter(user_id__in = user_ids)
        #得到所学过的课程的id
        courses_ids = [all_user_course.course_id for all_user_course in all_user_courses]
        #根据课程id获得所有的课程 并根据点击量排序
        relate_courses = Course.objects.filter(id__in = courses_ids).order_by('-click_nums')[:5]
        return render(request,'course-comment.html',{
            'course':course,
            'course_resource': course_resource,
            'all_comments':all_comments,
            'relate_courses': relate_courses,

        })


class addCommentView(View):
    def post(self,request):
        course_id = request.POST.get('course_id',0)
        comments = request.POST.get('comments','')
        user = request.user
        if not user.is_authenticated:
            return HttpResponse('{"status":"fail","msg":"用户未登录"}',content_type='application/json')
        else:
            if int(course_id) > 0 and comments:
                course_comment = CourseComments()
                course_comment.user = user
                course_comment.course_id = course_id
                course_comment.comments = comments
                course_comment.save()
                return HttpResponse('{"status":"success","msg":"发表成功"}',content_type='application/json')
            else:
                return HttpResponse('{"status":"fail","msg":"发表失败"}', content_type='application/json')



