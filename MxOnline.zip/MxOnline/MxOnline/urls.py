"""MxOnline URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
import xadmin
from django.contrib import admin
#from django.urls import path
from django.conf.urls import url,include
from django.views.generic import TemplateView
from django.views.static import serve
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static

from users import  views

from MxOnline.settings import MEDIA_ROOT,STATICFILES_DIRS

urlpatterns = [
    url('xadmin/', xadmin.site.urls),
    url('^$',views.indexView.as_view(),name="index"),
    url('^login/$',views.LoginView.as_view(),name="login"),
    url(r'^logout/$',views.LogoutView.as_view(),name='logout'),
    url('^register/$',views.RegisterView.as_view(),name='register'),
    url(r'^captcha/', include('captcha.urls')),
    url(r'^activate/(?P<code>.*)/$',views.Active_User.as_view(),name='active_user'),
    url(r'^forget/$',views.ForgetView.as_view(),name='forget'),
    url(r'^reset/(?P<code>.*)/$',views.ResetView.as_view(),name='reset_pwd'),
    url(r'^modify_pwd/$',views.ModifyView.as_view(),name='modify_pwd'),

    #课程机构的路由
    url(r'^org/',include(('organization.urls','organization'),namespace='org')),
    #课程路由
    url(r'^course/',include(('courses.urls','courses'),namespace='courses')),
    #user路由
    url(r'^users/',include(('users.urls','users'),namespace='users')),
    #配置上传文件的访问处理函数

    url(r'^media/(?P<path>.*)$',serve,{"document_root":MEDIA_ROOT}),
    url(r'^static/(?P<path>.*)$',serve,{"document_root":STATICFILES_DIRS[0]}),


]

#全局404配置
# handler404 = views.page_not_found
# handler500 = views.page_error
